﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;
using Application = Microsoft.Office.Interop.Word.Application;

namespace WindowsFormsMailMaergeApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void on_buttob_click(object sender, EventArgs e)
        {
            Application app = new Application();
            Document doc = new Document();

            doc = app.Documents.Add(Template: @"C:\Users\avinash.bobba\Desktop\Test Results\DataMerge.docx");
            app.Visible = true;
            

            foreach (Field mergeField in doc.Fields)
            {
                if (mergeField.Code.Text.Contains("FirstName"))
                {
                    mergeField.Select();
                    app.Selection.TypeText("Avinash");
                }
                else if (mergeField.Code.Text.Contains("LastName"))
                {
                    mergeField.Select();
                    app.Selection.TypeText("Bobba");
                }
                else if (mergeField.Code.Text.Contains("DateOfJoin"))
                {
                    mergeField.Select();
                    app.Selection.TypeText(Convert.ToString(DateTime.Now));
                }
                else if (mergeField.Code.Text.Contains("Organization"))
                {
                    mergeField.Select();
                    app.Selection.TypeText(Convert.ToString(DateTime.Now));
                }

                doc.SaveAs(FileName: @"C:\Users\avinash.bobba\Desktop\Test Results\SaveDataMerge.docx");
                doc.Close();
                app.Quit();
            }
        }
    }
}
